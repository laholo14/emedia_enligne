<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="vue/css/500.css" type="text/css">
    <title>500 error</title>
</head>
<style>

    
</style>
<body>
    
    
<h5> Erreur Interne du Serveur !</h5>
    <h1>5</h1>
    <h1>00</h1>
    <div class="box">
			<span></span><span></span>
			<span></span><span></span>
			<span></span>
		</div>
    <div class="box">
			<span></span><span></span>
			<span></span><span></span>
			<span></span>
		</div>
    


</body>
</html>