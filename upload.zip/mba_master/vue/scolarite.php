
    <?php
     $currentPage='scolarite';
    include ('include/header.php');
    include_once('include/script.php');
    ?>
</body>

</html>