<?php 

 header("location: mba_master/vue/inscription");

?>