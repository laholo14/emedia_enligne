<?php 

 header("location: master/vue/cours");

?>